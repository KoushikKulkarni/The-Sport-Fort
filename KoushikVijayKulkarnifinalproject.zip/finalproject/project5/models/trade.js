const mongoose= require('mongoose');
const Schema= mongoose.Schema;

const tradeScehma= new Schema({
    requesterId:{type: Schema.Types.ObjectId},
    ownerId: {type: Schema.Types.ObjectId},
    tradeProductId:{type: Schema.Types.ObjectId},
    offeredProductID: {type: Schema.Types.ObjectId},
    requesterName: {type: String},
    ownerName: {type: String},
    RequesterProductName: { type: String },
    ReceiverProductName: { type: String },
    tradeStatus: {type: String,default:"pending"}
},
{
    timestamps:true
});

module.exports = mongoose.model('trades',tradeScehma);