// const { Console } = require("console");
// const { DateTime } = require("luxon");
// const { v4: uuidv4 } = require("uuid");

// const categories = [
//   {
//     // id: 1,
//     // title: "A funny story",
//     // content:
//     //   "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
//     // author: "John Doe",
//     // createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT),
//     id: 1,
//     title: "Football",
//     image: 'images/football.jpg'
//   },
//   {
//     id: 2,
//     title: "Cricket",
//     image: 'images/cricket.jpg'
//   },
//   {
//     id: 3,
//     title: "Tennis",
//     image: 'images/tennis.jpg'
//   },
//   {
//     id: 4,
//     title: "Chess",
//     image: 'images/chess.jpg' 
//   }
// ];

// const Products = [
//   {
//     Category_id : 1,
//     product_id : 1,
//     category_name : "Football",
//     Product_name : "Football",
//     Desc: "Brand: Addidas,Year : 2020,condition : used-new Traditional soccer ball design with a modern touch.This machine-sewn ball has a High Air Retention (HAR) bladder which holds air really well.This allows the soccer ball to have the right amount of bounce while also retaining its shape over time.    Made with environmentally friendly material that is neither too hard nor too soft and allows for great control when dribbling and shooting, while also being comfortable when heading the ball.The ball comes deflated to protect it during shipping. This also reduces the amount of space the ball takes on shipping trucks helping reduce our carbon footprint.This soccer ball is great for natural or artificial grass, ideal for recreational purposes. Suitable for all weather types.",
//     image: '/images/addidas.png'
//   },
//   {
//     Category_id : 1,
//     product_id : 2,
//     category_name : "Football",
//     Product_name : "Gloves",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/fbgloves.jpg'
//   },
//    {
//     Category_id : 1,
//     product_id : 3,
//     category_name : "Football",
//     Product_name : "Shoes",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/addidas.png'
//   },
//   {
//     Category_id : 2,
//     product_id : 4,
//     category_name : "Cricket",
//     Product_name : "Bat",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/mrf.png'
//   },
//   {
//     Category_id : 2,
//     product_id : 5,
//     category_name : "Cricket",
//     Product_name : "Ball",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/cb.jpg'
//   },
//   {
//     Category_id : 2,
//     product_id : 6,
//     category_name : "Football",
//     Product_name : "Gloves",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/addidas.png'
//   },
//   {
//     Category_id : 3,
//     product_id : 7,
//     category_name : "Tennis",
//     Product_name : "Racquet",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/tracket.jpg'
//   },
//   {
//     Category_id : 3,
//     product_id : 8,
//     category_name : "Tennis",
//     Product_name : "Tennis Balls",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/tballs.jpg'
//   },
//   {
//     Category_id : 3,
//     product_id : 9,
//     category_name : "Tennis",
//     Product_name : "Headband",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/addidas.png'
//   },
//   {
//     Category_id : 4,
//     product_id : 10,
//     category_name : "Chess",
//     Product_name : "Wood Chessboard",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/woodencb.jpg'
//   },
//   {
//     Category_id : 4,
//     product_id : 11,
//     category_name : "Chess",
//     Product_name : "Metal Chessboard",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/metalcb.jpg'
//    },
//   {
//     Category_id : 4,
//     product_id : 12,
//     category_name : "Chess",
//     Product_name : "Marble Chessboard",
//     Desc: "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
//     image: '../images/addidas.png'
//   }
// ];

// exports.find = () =>{
//   let resultArray=[]

//  categories.forEach(cat=>{
//     let tempobj=[]
//     tempobj=Products.filter(product=>{
//       return product.Category_id==cat.id
//     })
//     cat.products=tempobj
//     resultArray.push(cat)
//    // console.log(resultArray)
   
//  })
//  return resultArray
// } ;

// exports.findById = (id) => {
//   return Products.find((c) => c.product_id == id);
// };

// // exports.save = (story) => {
// //   story.createdAt = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
// //   story.id = uuidv4();
// //   stories.push(story);
// // };

// exports.save = function(trade){
//   //console.log(trade)
//   let result=categories.find((obj)=>{
//       return obj.title==trade.category
//   })
//  // console.log(result)
//   if(result==undefined){
//       var tempobj={}
//       var tempobj2={}
//       tempobj.title= trade.category
//       tempobj.id=uuidv4()
//       // if(trade.image==""){
//           tempobj.image="/images/all.jpg"
//       // }else{
//       //     tempobj.image=trade.image
//       // }
      
//       tempobj2.Category_id = tempobj.id
//       tempobj2.product_id = uuidv4()
//       tempobj2.category_name = trade.category
//       tempobj2.Product_name = trade.product
//       tempobj2.Desc = trade.desc
//       if(trade.image==""){
//         tempobj2.image="/images/all.jpg"
//      }else{
//          tempobj2.image="/images/"+trade.image
//      }
//       categories.push(tempobj)
//      // console.log(tempobj2)
//       Products.push(tempobj2)
//       return true;
//       }
//       else{
//         var tempobj2={}
//         tempobj2.Category_id = result.id
//         tempobj2.product_id = uuidv4()
//         tempobj2.category_name = trade.category
//         tempobj2.Product_name = trade.product
//         tempobj2.Desc = trade.desc
//     //    categories.push(tempobj)
//        // console.log(tempobj2)
//         Products.push(tempobj2)
//         return true;
//   }
//   }

// exports.updateByID = (id, newStory) => {
//   let result= categories.find(obj=>{
//     return obj.title == newStory.category
// })

// let story = Products.find(story=> story.product_id == id);
// // console.log(story);
// //console.log(result)
// if(result==undefined){
//     let tempobj={}
//     tempobj.title=newStory.category;
//     tempobj.id=uuidv4();
//     tempobj.image="/images/all.jpg"

//     categories.push(tempobj);
          
//     story.Category_id = tempobj.id;             
//     story.category_name = tempobj.Category_name;
//     story.Product_name = newStory.product;
//     if(!newStory.image){
//       story.image = story.image
//    }else{
//        story.image="/images/"+newStory.image
//    }
//     story.Desc = newStory.desc;        
//     return true;
// }else{
//     story.Category_id = result.id;             
//     story.category_name = story.category_name;
//     story.Product_name = newStory.product;
//     if(!newStory.image){
//       story.image = story.image
//    }else{
//        story.image="/images/"+newStory.image
//    }
//     story.Desc = newStory.desc; 
//     return true;
// }    
// };

// exports.deleteByID = (id) => {
//   let index = Products.findIndex((story) => story.product_id == id);
//   if (index !== -1) {
//     Products.splice(index, 1);
//     return true;
//   } else {
//     return false;
//   }
// };

const mongoose= require('mongoose');
const Schema= mongoose.Schema;

const categorySchema= new Schema({
    title:{type:String,required:[true,'category is required']},
    image:{type:String,default:"/images/all.jpg"}
},
{
    timestamps:true
});
const productSchema= new Schema({
  category_name:{type:String,required:[true,'category is required']},
  Product_name:{type:String,required:[true,'product is required']},
  author: {type: Schema.Types.ObjectId,ref:'User'},
  author_name: {type: String},
  desc: {type:String},
  image:{type:String},
  status:{type: String}
},
{
  timestamps:true
});

const category = mongoose.model('Category',categorySchema);
const product  = mongoose.model('Product',productSchema);
module.exports = {category,product};



