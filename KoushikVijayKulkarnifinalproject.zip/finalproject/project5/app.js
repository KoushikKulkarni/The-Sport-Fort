const express = require("express");
const methodOverride=require("method-override");
const app = express();

const mongoose =  require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const flash = require('connect-flash');

const morgan = require("morgan");
const User = require("./models/user");

app.use(morgan("tiny"));
app.use(methodOverride('_method'));
app.use(express.static("public"));

app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");

const storyRouters = require("./routes/storyRoutes");
const generalRouters = require("./routes/generalRoutes");
const userRouters = require("./routes/userRoutes");

// app.get("/", (req, res) => {
//   res.render("index");
// });

// app.get("/contact", (req, res) => {
//   res.render("story/contact");
// });
// app.get("/about", (req, res) => {
//   res.render("story/about");
// });

mongoose.connect('mongodb://localhost:27017/trade',{useNewUrlParser: true,useUnifiedTopology: true})
.then(()=>{
//start the server
let port = 3000;
let host = "localhost";
app.listen(port, host, ()=>{
    console.log('Server is running on port', port);
})
})
.catch(err=>console.log(err.message))

app.use(
  session({
      secret: "ajfeirf90aeu9eroejfoefj",
      resave: false,
      saveUninitialized: false,
      store: new MongoStore({mongoUrl: 'mongodb://localhost:27017/trade'}),
      cookie: {maxAge: 60*60*1000}
      })
);
app.use(flash());

app.use((req, res, next) => {
  //console.log(req.session);
  res.locals.user = req.session.user||null;
  res.locals.fullname = req.session.fullname;
  res.locals.errorMessages = req.flash('error');
  res.locals.successMessages = req.flash('success');
  next();
});


app.use("/trades", storyRouters);


app.use("/", generalRouters);

app.use('/users', userRouters);


app.use((req, res, next) => {
  let err = new Error("Serevr cannot locate the given URL " + req.url);
  err.status = 404;
  next(err);
});

app.use((err, req, res, next) => {
  console.log(err.stack);
  if (!err.status) {
    err.status = 500;
    err.message = "Internal server error";
  }
  res.status(err.status);
  res.render("error", { error: err });
});

