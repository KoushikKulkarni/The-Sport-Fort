const { category, product } = require("../models/story");

const {validationResult} = require('express-validator')
const {body} = require('express-validator')

exports.validateId = (req,res,next)=>{
    let id = req.params.id;
    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid product id');
        err.status = 400;
        req.flash('error',err.message);
        return res.redirect('back');
    }
    else{
        return next();
    }
}


exports.validateSignUp=[body('firstName',"firstName cannot be empty").notEmpty().trim().escape(),body('lastName','lastName cannot be empty').notEmpty().trim().escape(),body('email','Email must be a valid email address').isEmail().trim().escape().normalizeEmail(), 
body('password','Password must be atleast 8 character and atmost 64 character').isLength({min:8,max:64})];

exports.validateLogIn=[body('email','Email must be a valid email address').isEmail().trim().escape().normalizeEmail(), 
body('password','Password must be atleast 8 character and atmost 64 character').isLength({min:8,max:64})];

exports.validateResult=(req,res,next)=>{
    let errors=validationResult(req)
    if(!errors.isEmpty()){
        errors.array().forEach(error=>{
            req.flash('error',error.msg);
        });
        return res.redirect('back')
    }else{
        next()
    }
}

exports.validateStory=[body('category','Category cannot be empty!').notEmpty().trim().escape(), 
body('product','Product name cannot be empty!').notEmpty().trim().escape(),
body('desc','Description must be of 20 characters at least !').notEmpty().isLength({min:20}).trim().escape(),
body('image','Please upload the image of the product!').notEmpty().trim()];
