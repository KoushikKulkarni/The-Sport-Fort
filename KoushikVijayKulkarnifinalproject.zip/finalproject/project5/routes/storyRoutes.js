const express = require("express");
const controller = require("../controllers/storyController");

const{isLoggedIn,isAuthor, isGuest} = require('../middlewares/auth'); 
const{validateId,validateStory,validateResult} = require('../middlewares/validator'); 
const router = express.Router();

//  router.get("/", controller.index);

 router.get("/", controller.trades);
// router.get('/',(req,res)=>{

//     res.send("trades page is here")
// });

router.get("/new",isLoggedIn, controller.new);

//router.get("/new", controller.new);

 router.post("/",isLoggedIn,validateStory,validateResult, controller.create);

 router.get('/:id/makeatrade', isLoggedIn, controller.makeTrade);

 router.post('/:id/tradeHistory', isLoggedIn, controller.createTrade);

 router.get('/tradeHistory', isLoggedIn, controller.displayTradeHistory);

 router.post('/cancelOffer/:id', controller.cancelOffer);

 router.post('/accept/:id', controller.acceptOffer);

router.post('/decline/:id', controller.declineOffer);

router.post('/watch/:id', controller.watch);

router.post('/unwatch/:id', controller.unwatch);

router.post('/unwatchlist/:id', controller.unwatchlist);

router.get('/getwatchitems',controller.getwatchitems);

router.get('/tradeOffers', isLoggedIn, controller.displayTradeOffers);

router.get('/pendingOffers', isLoggedIn, controller.displayPendingOffers);

 router.get("/:id",validateId, controller.show);

 router.get("/:id/edit",isLoggedIn,isAuthor,validateId, controller.edit);


 router.put("/:id",validateId,isLoggedIn,isAuthor,validateStory,validateResult, controller.update);

 router.delete("/:id/deletep",isLoggedIn,isAuthor,validateId, controller.deletep);

 router.delete("/:id",isLoggedIn,isAuthor,validateId, controller.delete);




module.exports = router;
