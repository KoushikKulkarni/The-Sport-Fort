const express = require('express');
const controller = require('../controllers/userController');
const {isGuest,isLoggedIn} = require('../middlewares/auth');
const {validateSignUp,validateLogIn,validateResult}= require('../middlewares/validator');
const {logInLimiter} = require('../middlewares/rateLimiters');
const router = express.Router();

//GET /users/new: send html form for creating a new user account

router.get('/signup',isGuest,controller.signup);

router.post('/',isGuest,validateSignUp,validateResult, controller.create);

router.get('/login',isGuest, controller.getUserLogin);



//POST /users/login: authenticate user's login
router.post('/login',isGuest,logInLimiter,validateLogIn,validateResult, controller.login);

router.get('/profile',isLoggedIn,controller.profile);

router.get('/logout',isLoggedIn, controller.logout);

module.exports = router;