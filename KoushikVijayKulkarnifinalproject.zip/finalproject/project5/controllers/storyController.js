const { category, product } = require("../models/story");
const model = require('../models/user');


const trades = require('../models/trade');
const trade = require("../models/trade");

// exports.index = (req, res) => {
//   let stories = model.find();
//   res.render("./story/index", { categories });
// };

exports.new = (req, res) => {
  res.render("./story/newTrade");
};
exports.trades = (req, res) => {
  category.aggregate([
    {
      $lookup: {
        from: "products",
        localField: "title",
        foreignField: "category_name",
        as: "products"
      }
    },
    {
      $unwind: {
          path: "$products"
      }
  },
  {
      $match: {
          "products.status": "available"
      }
  },
  {
      $group: {
          _id: "$title",
          title: { $first: "$title" },
          image: { $first: "$image" },
          products: { $push: "$products" }
      }
  },
    {
      $sort: { title: 1 }
    }
  ])
    .then(categories => {
      // console.log(categories);
      res.render('./story/trades', { categories });
    })
    .catch(err => next(err))
};

exports.create = (req, res, next) => {
  let story = req.body;
  //model.save(story);
  category.find({ title: story.category })
    .then(it => {
      if (it.length == 0) {
        let s = new category({ title: story.category })
        s.save()
          .then(() => {
            console.log("inside this")
            let p = new product({ author: req.session.user, category_name: story.category, Product_name: story.product, desc: story.desc, 
              author_name: req.session.fullname,status: "available",image: "/images/" + story.image });
            p.save()
              .then(() => {
                req.flash('success', 'Product is added successfully');
                res.redirect('/trades');
              })
              .catch(err => next(err))
          })
          .catch(err => next(err))
      }
      else {
        let p = new product({ author: req.session.user, category_name: story.category, Product_name: story.product, desc: story.desc,
          author_name: req.session.fullname,status: "available", image: "/images/" + story.image })
        p.save()
          .then(() => {
             req.flash('success','Product is added successfully');
            res.redirect('/trades');
          })
          .catch(err => next(err))

      }
    }
    )
    .catch(err => next(err))
  //console.log(story);
};

exports.show = (req, res, next) => {
  // console.log("*************************"+req.params.id)
  let id = req.params.id
  // if (!id.match(/^[0-9a-fA-F]{24}$/)) {
  //       let err = new Error('Invalid item id');
  //       err.status = 400;
  //       return next(err);
  //   }
  product.findById(id)
    .then(story => {
      if (story) {
        trade.find({$and:[{requesterId: req.session.user,tradeProductId: id,tradeStatus:"pending"}]})
        .then((res1)=>{
          story.flag = false;
          if(res1.length > 0){
            story.flag = true;
          }
          story.flag2 = false;
          model.find({_id: req.session.user, watchlist: id})
          .then(result =>{
            console.log("sfnsfnskf fw k"+result);
            if(result.length > 0){
              story.flag2 = true;
            }
            res.render('./story/trade', { story });
                            })
            .catch(err => next(err))
          })
          .catch(err => next(err))

      } else {
        let err = new Error('No Item with id ' + id + ' found. Please re-check the entered id !');
        err.status = 404;
        next(err);
      }
      //console.log(result)
    })
    .catch(err => next(err))
};


exports.edit = (req, res, next) => {
  let id = req.params.id;
  // if (!id.match(/^[0-9a-fA-F]{24}$/)) {
  //     let err = new Error('Invalid item id');
  //     err.status = 400;
  //     return next(err);
  // }

  product.findById(id)
    .then(story => {
      if (story) {
        category.find({ title: story.category_name })
          .then(result => {
            let cat = {}
            cat.title = result[0].catName
            res.render('./story/edit', { story, cat });
          })

      }
      else {
        let err = new Error('No Item with id ' + id + ' found. Please re-check the entered id !');
        err.status = 404;
        next(err);
      }
    })
    .catch(err => next(err))
};


exports.update = (req, res, next) => {
  console.log(req.body)
  let trade = req.body;
  let id = req.params.id;
  // if (!id.match(/^[0-9a-fA-F]{24}$/)) {
  //     let err = new Error('Invalid item id');
  //     err.status = 400;
  //     return next(err);
  // }
  category.find({ title: trade.category })
    .then(result => {
      console.log(result);
      if (result.length > 0) {
        product.updateOne({ _id: id }, {
          $set: {
            category_name: trade.category, Product_name: trade.product,
            image: trade.image, desc: trade.desc
          }
        }, { runValidators: true })
          .then(trade => {
            if (trade) {
              req.flash('success', 'Update successful !');
              res.redirect('/trades/' + id);
            } else {
              let err = new Error('Invalid item id');
              err.status = 404;
              next(err);
            }
          })
          .catch(err => {
            if (err.name == "ValidationError") {
              err.status = 400;
            }
            next(err);
          })
      } else {
        console.log("here")
        let cat = new category({ title: trade.category })
        cat.save()
          .then(() => {
            console.log("here11")
          })
          .catch(err => {
            if (err.name == "ValidationError") {
              err.status = 400;
            }
            next(err);
          });
        product.updateOne({ _id: id }, {
          $set: {
            category_name: trade.category, Product_name: trade.product,
            image: +trade.image, desc: trade.desc
          }
        }, { runValidators: true })
          .then(trade => {
            if (trade) {
              req.flash('success', 'Product is added successfully');
              res.redirect('/trades/' + id);
            } else {
              let err = new Error('Invalid item id');
              err.status = 404;
              next(err);
            }
          })
          .catch(err => {
            if (err.name == "ValidationError") {
              err.status = 400;
            }
            next(err);
          })
      }
    })
    .catch(err => next(err))
};
exports.delete = (req, res, next) => {
  let id = req.params.id;
  // if (!id.match(/^[0-9a-fA-F]{24}$/)) {
  //     let err = new Error('Invalid item id');
  //     err.status = 400;
  //     return next(err);
  // }
  product.findByIdAndDelete(id, { useFindAndModify: false })
    .then(trade => {
      if (trade) {
        trades.updateMany({ $or: [{ offeredProductID: id }, { tradeProductId: id }], tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } })
            .then(result => {
                res.redirect('/trades');
            })
            .catch(err => next(err))
      }
     else {
        let err = new Error('No Item with id ' + id + ' found to delete');
        err.status = 404;
        next(err);
      }
    })
    .catch(err => next(err));
};

exports.deletep = (req, res, next) => {
  let id = req.params.id;
  // if (!id.match(/^[0-9a-fA-F]{24}$/)) {
  //     let err = new Error('Invalid item id');
  //     err.status = 400;
  //     return next(err);
  // }
  product.findByIdAndDelete(id, { useFindAndModify: false })
    .then(trade => {
      if (trade) {
        trades.updateMany({ $or: [{ offeredProductID: id }, { tradeProductId: id }], tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } })
            .then(result => {
                res.redirect('/users/profile');
            })
            .catch(err => next(err))
      }
     else {
        let err = new Error('No Item with id ' + id + ' found to delete');
        err.status = 404;
        next(err);
      }
    })
    .catch(err => next(err));
};



exports.makeTrade = (req, res, next) => {
  let existingProduct = [];
  let productId = req.params.id;
  trades.find({ requesterId: req.session.user })
      .then(tradesp => {
          if (tradesp.length > 0) {
               console.log(tradesp)
              tradesp.forEach(trade => {
                  if (trade.tradeStatus == "pending" || trade.tradeStatus == "accepted")
                      existingProduct.push(trade.offeredProductID);
              })
          }
              //console.log("hhh"+existingProduct)
              product.find({ author: req.session.user, _id: { $nin: existingProduct },status: "available" })
                  .then(products => {
                       console.log("your products"+products)
                      if (products.length > 0) {
                          res.render('./story/offerproduct', { products, productId })
                      } else {
                          let err = new Error("You don't have any product to trade");
                          err.status = 404;
                          next(err);
                      }
                  })
                  .catch(err => next(err))
          //  else {
          //     let products = []
          //     res.render('./story/offerproduct', { products, productId })
          // }
      })
      .catch(err => next(err))

};

exports.createTrade = (req, res, next) => {
  let tradesDetail = {}
  console.log(req.params.id);
  tradesDetail.tradeProductId = req.params.id;
  tradesDetail.offeredProductID = req.body.product; 
  tradesDetail.requesterId = req.session.user;

  product.findById(tradesDetail.tradeProductId)
      .then(product1 => {
          tradesDetail.ownerId = product1.author;
          tradesDetail.ReceiverProductName = product1.Product_name;
          Promise.all([model.findById(tradesDetail.ownerId), model.findById(tradesDetail.requesterId),
          product.findById(tradesDetail.offeredProductID)])
              .then(user1 => {
                  tradesDetail.ownerName = user1[0].firstName + " " + user1[0].lastName;
                  tradesDetail.requesterName = user1[1].firstName + " " + user1[1].lastName;
                  tradesDetail.RequesterProductName = user1[2].Product_name;
                  //console.log(tradesDetail)
                  let trade1 = new trades(tradesDetail);
                  trade1.save()
                      .then(() => {
                          res.redirect('/trades/pendingoffers');
                      })
                      .catch(err => next(err))
              })
              .catch(err => next(err))
      })
      .catch(err => next(err))


};
exports.displayPendingOffers= (req, res, next) => {
  let myTradeOffers = [];
  let myTradeHistory = [];
  let userId = req.session.user;
  trades.find({ $and: [{ requesterId: userId }, { tradeStatus: "pending" }] })
      .then(tradesp => {
          if (tradesp.length > 0) {
              myTradeOffers = tradesp;
          }
          trades.find({ $or: [{ requesterId: userId }, { ownerId: userId }] })
              .sort({ createdAt: -1 })
              .then(tradesp1 => {
                  if (tradesp1.length > 0) {
                      myTradeHistory = tradesp1;
                  }
                  res.render('./story/pendingOffers', { myTradeOffers, myTradeHistory });
              })
              .catch(err => next(err))
      })
      .catch(err => next(err))
};


exports.displayTradeHistory = (req, res, next) => {
  let myTradeOffers = [];
  let myTradeHistory = [];
  let userId = req.session.user;
  trades.find({ $and: [{ requesterId: userId }, { tradeStatus: "pending" }] })
      .then(tradesp => {
          if (tradesp.length > 0) {
              myTradeOffers = tradesp;
          }
          trades.find({ $or: [{ requesterId: userId }, { ownerId: userId }] })
              .sort({ createdAt: -1 })
              .then(tradesp1 => {
                  if (tradesp1.length > 0) {
                      myTradeHistory = tradesp1;
                  }
                  res.render('./story/tradeHistory', { myTradeOffers, myTradeHistory });
              })
              .catch(err => next(err))
      })
      .catch(err => next(err))
};
exports.cancelOffer = (req, res, next) => {
  let tradeID = req.params.id;
  trades.findById(tradeID)
      .then(result => {
          trades.updateOne({ _id: tradeID }, { $set: { tradeStatus: "cancelled" } })
              .then(() => {
                  req.flash('success', 'Your Trade is Cancelled Successfully');
                  res.redirect('/trades/pendingoffers')
              }
              )
              .catch(err => next(err))
      })
      .catch(err => next(err))
};

exports.displayTradeOffers = (req, res, next) => {
  let myTradeOffers = [];
  let userId = req.session.user;
  trades.find({ $and: [{ ownerId: userId }, { tradeStatus: "pending" }] })
      .then(tradesp => {
          if (tradesp.length > 0) {
              myTradeOffers = tradesp;
          }
          res.render('./story/mytradeoffers', { myTradeOffers })
      })
      .catch(err => next(err))
};

exports.acceptOffer = (req, res, next) => {
  let tradeID = req.params.id;
  trades.findById(tradeID)
      .then(result1 => {
          trades.updateOne({ _id: tradeID }, { $set: { tradeStatus: "accepted" } })
              .then(result => {
                  product.updateMany({ $or: [{ _id: result1.offeredProductID }, { _id: result1.tradeProductId }] }, { $set: { status: "Not available" } })
                      .then(() => {
                        Promise.all([
                          trades.updateMany({ tradeProductId: result1.tradeProductId, tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } }),
                          trades.updateMany({ offeredProductID: result1.offeredProductID, tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } }),
                          trades.updateMany({ tradeProductId: result1.offeredProductID, tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } }),
                          trades.updateMany({ offeredProductID: result1.tradeProductId, tradeStatus: "pending" }, { $set: { tradeStatus: "rejected" } })])
                          .then(res1 => {
                              // console.log(res1)
                              req.flash('success', 'Trade Accepted Successfully');
                              res.redirect('/trades/tradeoffers')
                          })
                      })
                      .catch(err => next(err))
              }
              )
              .catch(err => next(err))
      })
      .catch(err => next(err))
};

exports.declineOffer = (req, res, next) => {
  let tradeID = req.params.id;
  trades.findById(tradeID)
      .then(result => {
          trades.updateOne({ _id: tradeID }, { $set: { tradeStatus: "declined" } })
              .then(() => {
                  req.flash('error', 'Trade declined Successfully');
                  res.redirect('/trades/tradeoffers')
              }
              )
              .catch(err => next(err))
      })
      .catch(err => next(err))
};

exports.watch = (req,res,next) =>{
  console.log("watch me before I leave");
  let productid = req.params.id;
  let user = req.session.user;

  model.findById(req.session.user )
  .then(result => {
    if(result){
      console.log(result);
      result.watchlist.push(productid);
      console.log(result);
      model.updateOne({ _id: user }, { $push: { 'watchlist': productid } })
      .then(() => {
        req.flash('success', 'Added to watchlist');
        res.redirect('/trades/'+productid)
    }
    )
    .catch(err => next(err))
  }
  else {
    let err = new Error('No Item with id ' + id + ' found. Please re-check the entered id !');
    err.status = 404;
    next(err);
  }
  })
  .catch(err => next(err))
};

exports.unwatch = (req,res,next) =>{
  console.log("unwatch me before I leave");
  let productid = req.params.id;
  let user = req.session.user;

  model.findById(req.session.user )
  .then(result => {
    if(result){
      console.log(result);
      result.watchlist.push(productid);
      console.log(result);
      model.updateOne({ _id: user }, { $pull: { 'watchlist': productid } })
      .then(() => {
        req.flash('success', 'Removed from watchlist successfully!');
        res.redirect('/trades/'+productid)
    }
    )
    .catch(err => next(err))
  }
  else {
    let err = new Error('No Item with id ' + id + ' found. Please re-check the entered id !');
    err.status = 404;
    next(err);
  }
  })
  .catch(err => next(err))
};


exports.unwatchlist = (req,res,next) =>{
  console.log("unwatch me before I leave");
  let productid = req.params.id;
  let user = req.session.user;

  model.findById(req.session.user )
  .then(result => {
    if(result){
      console.log(result);
      result.watchlist.push(productid);
      console.log(result);
      model.updateOne({ _id: user }, { $pull: { 'watchlist': productid } })
      .then(() => {
        req.flash('success', 'Removed from watchlist successfully!');
        res.redirect('/trades/getwatchitems');
    }
    )
    .catch(err => next(err))
  }
  else {
    let err = new Error('No Item with id ' + id + ' found. Please re-check the entered id !');
    err.status = 404;
    next(err);
  }
  })
  .catch(err => next(err))
};

exports.getwatchitems = (req,res,next) =>{
  console.log("get your watchlist here");
  model.findById(req.session.user )
  .then(result => {
    watchlist = result.watchlist;
    product.find({_id:{$in:watchlist}})
    .then(mywatchlist=>{
      res.render('./story/watchlist', { mywatchlist })
    })
    .catch(err => next(err))
    // if(result>0){
    //   console.log(result);
    //     mywatchlist = result.watchlist;
    // }
   
    }
    )
    .catch(err => next(err))
}